<?php

return [
  /**
   * --------------------------------------------------------------------------
   * User Types
   * --------------------------------------------------------------------------
   * This value is array of user type. Default type are admin and user.
   */
  'user_types' => [
    'Admin',
    'User',
    'Visitor'
  ],
];
