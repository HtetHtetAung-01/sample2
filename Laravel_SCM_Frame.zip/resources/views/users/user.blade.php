@extends('layouts.app')

@section('content')
<div>
  Testing
</div>
@endsection
