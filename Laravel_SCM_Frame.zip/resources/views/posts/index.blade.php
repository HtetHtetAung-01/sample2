<table class="table table-striped">
  @foreach($contacts as $contact)
  
  @endforeach
</table>