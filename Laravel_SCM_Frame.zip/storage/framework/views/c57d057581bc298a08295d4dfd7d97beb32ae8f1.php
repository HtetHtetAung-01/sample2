

<?php $__env->startSection('content'); ?>
<!-- Styles -->
<link href="<?php echo e(asset('css/lib/jquery.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/post-list.css')); ?>" rel="stylesheet">

<!-- Script -->
<script src="<?php echo e(asset('js/lib/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/lib/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/post-list.js')); ?>"></script>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header"><?php echo e(__('Post List')); ?></div>
        <div class="card-body">
          <div class="row mb-2 search-bar">
            <label class="p-2 search-lbl">Keyword :</label>
            <input class="search-input mb-2 form-control" type="text" id="search-keyword" />
            <button class="btn btn-primary mb-2 search-btn" id="search-click">Search</button>
            <?php if(auth()->user() && (auth()->user()->type == 0 || auth()->user()->type == 1)): ?>
            <a class="btn btn-primary header-btn" href="/post/create"><?php echo e(__('Create')); ?></a>
            <a class="btn btn-primary header-btn" href="/post/upload"><?php echo e(__('Upload')); ?></a>
            <?php endif; ?>
            <a class="btn btn-primary header-btn" href="/post/download"><?php echo e(__('Download')); ?></a>
          </div>
          <table class="table table-hover" id="post-list">
            <thead>
              <tr>
                <th class="header-cell" scope="col">Post Title</th>
                <th class="header-cell" scope="col">Post Description</th>
                <th class="header-cell" scope="col">Posted User</th>
                <th class="header-cell" scope="col">Posted Date</th>
                <?php if(auth()->user() && (auth()->user()->type == 0 || auth()->user()->type == 1)): ?>
                <th class="header-cell" scope="col">Operation</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $postList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <a class="post-name" onclick="showPostDetail(<?php echo e(json_encode($post)); ?>)" data-toggle="modal" data-target="#post-detail-popup"><?php echo e($post->title); ?></a>
                <td><?php echo e($post->description); ?></td>
                <td><?php echo e($post->created_user); ?></td>
                <td><?php echo e(date('Y/m/d', strtotime($post->created_at))); ?></td>
                <?php if(auth()->user() && (auth()->user()->type == 0 || auth()->user()->type == 1)): ?>
                <td>
                  <a type="button" class="btn btn-primary" href="/post/edit/<?php echo e($post->id); ?>">Edit</a>
                  <button onclick="showDeleteConfirm(<?php echo e(json_encode($post)); ?>)" type="button" class="btn btn-danger" data-toggle="modal" data-target="#post-delete-popup">Delete</button>
                </td>
                <?php endif; ?>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <div class="modal fade" id="post-detail-popup" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title"><?php echo e(__('Post Detail')); ?></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="post-detail">
                  <div class="col-md-12">
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('Title')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-title"></i>
                      </label>
                    </div>
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('Description')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-description"></i>
                      </label>
                    </div>
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('Status')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-status"></i>
                      </label>
                    </div>
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('Created Date')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-created-at"></i>
                      </label>
                    </div>
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('Created User')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-created-user"></i>
                      </label>
                    </div>
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('Updated Date')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-updated-at"></i>
                      </label>
                    </div>
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('Updated User')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-updated-user"></i>
                      </label>
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade" id="post-delete-popup" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title"><?php echo e(__('Delete Confirm')); ?></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="post-delete">
                  <h4 class="delete-confirm-header">Are you sure to delete post?</h4>
                  <div class="col-md-12">
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('ID')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-id"></i>
                      </label>
                    </div>
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('Title')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-title"></i>
                      </label>
                    </div>
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('Description')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-description"></i>
                      </label>
                    </div>
                    <div class="row">
                      <label class="col-md-4 text-md-left"><?php echo e(__('Status')); ?></label>
                      <label class="col-md-8 text-md-left">
                        <i class="post-text" id="post-status"></i>
                      </label>
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button onclick="deletePostById(<?php echo e(json_encode(csrf_token())); ?>)" type="button" class="btn btn-danger">Delete</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\git\bulletinboard\Bulletin\resources\views/posts/list.blade.php ENDPATH**/ ?>