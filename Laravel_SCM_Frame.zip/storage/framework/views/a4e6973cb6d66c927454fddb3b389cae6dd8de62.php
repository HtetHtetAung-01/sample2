

<?php $__env->startSection('content'); ?>
<!-- Styles -->
<link href="<?php echo e(asset('css/post-edit-confirm.css')); ?>" rel="stylesheet">

<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header"><?php echo e(__('Post Edit')); ?></div>

        <div class="card-body">
          <form method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group row">
              <label for="title" class="col-md-4 col-form-label text-md-right required"><?php echo e(__('Title')); ?></label>

              <div class="col-md-6">
                <input id="title" type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" value="<?php echo e(old('title')); ?>" required autocomplete="title" autofocus readonly="readonly">

                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div class="form-group row">
              <label for="description" class="col-md-4 col-form-label text-md-right required"><?php echo e(__('Description')); ?></label>

              <div class="col-md-6">
                <textarea id="description" type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" autocomplete="description" readonly="readonly"><?php echo e(old('description')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div class="form-group row">
              <label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Status')); ?></label>

              <div class="col-md-6 mt-auto mb-auto">
                <div class="custom-control custom-switch">
                  <?php if(old('status')): ?>
                  <input type="checkbox" class="custom-control-input" id="customSwitch1" name="status" checked onclick="return false;">
                  <label class="custom-control-label" for="customSwitch1"></label>
                  <?php else: ?>
                  <input type="checkbox" class="custom-control-input" id="customSwitch1" name="status" onclick="return false;">
                  <label class="custom-control-label" for="customSwitch1"></label>
                  <?php endif; ?>
                </div>
              </div>

            </div>

            <div class="form-group row mb-0">
              <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary">
                  <?php echo e(__('Confirm')); ?>

                </button>
                <a class="cancel-btn btn btn-secondary" onClick="window.history.back()"><?php echo e(__('Cancel')); ?></a>
              </div>
            </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\git\bulletinboard\Bulletin\resources\views/posts/edit-confirm.blade.php ENDPATH**/ ?>